import { Book } from '@/types/Book';

const API_URL = 'https://api.example.com'; // Replace with your actual API URL

export const bookService = {
  async getBooks(): Promise<Book[]> {
    try {
      const response = await fetch(`${API_URL}/books`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          // In a real app, we would include auth token
        },
      });

      if (!response.ok) {
        throw new Error('Failed to fetch books');
      }

      const data = await response.json();
      return data.books;
    } catch (error) {
      console.error('Fetch books error:', error);
      throw error;
    }
  },

  async getBookByIsbn(isbn: string): Promise<Book | null> {
    try {
      const response = await fetch(`${API_URL}/books/${isbn}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          // In a real app, we would include auth token
        },
      });

      if (!response.ok) {
        if (response.status === 404) {
          return null;
        }
        throw new Error('Failed to fetch book details');
      }

      const data = await response.json();
      return data.book;
    } catch (error) {
      console.error('Fetch book details error:', error);
      throw error;
    }
  },

  async issueBook(isbn: string, borrowerId: string): Promise<void> {
    try {
      const response = await fetch(`${API_URL}/books/issue`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          // In a real app, we would include auth token
        },
        body: JSON.stringify({ isbn, borrowerId }),
      });

      if (!response.ok) {
        throw new Error('Failed to issue book');
      }
    } catch (error) {
      console.error('Issue book error:', error);
      throw error;
    }
  },

  async returnBook(isbn: string): Promise<void> {
    try {
      const response = await fetch(`${API_URL}/books/return`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          // In a real app, we would include auth token
        },
        body: JSON.stringify({ isbn }),
      });

      if (!response.ok) {
        throw new Error('Failed to return book');
      }
    } catch (error) {
      console.error('Return book error:', error);
      throw error;
    }
  },

  async searchBooks(query: string): Promise<Book[]> {
    try {
      const response = await fetch(`${API_URL}/books/search?q=${encodeURIComponent(query)}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          // In a real app, we would include auth token
        },
      });

      if (!response.ok) {
        throw new Error('Failed to search books');
      }

      const data = await response.json();
      return data.books;
    } catch (error) {
      console.error('Search books error:', error);
      throw error;
    }
  }
};