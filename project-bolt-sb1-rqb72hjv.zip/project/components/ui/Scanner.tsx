import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Alert, Platform } from 'react-native';
import { BarCodeScanner, BarCodeScannerResult } from 'expo-barcode-scanner';
import { Camera } from 'lucide-react-native';
import Colors from '@/constants/Colors';
import Theme from '@/constants/Theme';
import Button from './Button';

interface ScannerProps {
  onScan: (isbn: string) => void;
  isEnabled: boolean;
}

const Scanner: React.FC<ScannerProps> = ({ onScan, isEnabled }) => {
  const [hasPermission, setHasPermission] = useState<boolean | null>(null);
  const [scanned, setScanned] = useState(false);

  useEffect(() => {
    const getBarCodeScannerPermissions = async () => {
      if (Platform.OS === 'web') {
        setHasPermission(true);
        return;
      }
      
      const { status } = await BarCodeScanner.requestPermissionsAsync();
      setHasPermission(status === 'granted');
    };

    getBarCodeScannerPermissions();
  }, []);

  const handleBarCodeScanned = ({ type, data }: BarCodeScannerResult) => {
    setScanned(true);
    
    // Check if the scanned code is a valid ISBN
    const isValidISBN = /^(?:\d[- ]?){9}[\dXx]$|^(?:\d[- ]?){13}$/.test(data.replace(/-/g, ''));
    
    if (isValidISBN) {
      onScan(data.replace(/-/g, ''));
    } else {
      Alert.alert(
        'Invalid Barcode',
        'The scanned barcode is not a valid ISBN format.',
        [{ text: 'OK', onPress: () => setScanned(false) }]
      );
    }
  };

  const handleScanAgain = () => {
    setScanned(false);
  };

  if (hasPermission === null) {
    return (
      <View style={styles.permissionContainer}>
        <Text style={styles.permissionText}>Requesting camera permission...</Text>
      </View>
    );
  }
  
  if (hasPermission === false) {
    return (
      <View style={styles.permissionContainer}>
        <Camera size={48} color={Colors.neutral[400]} />
        <Text style={styles.permissionText}>Camera permission not granted</Text>
        <Text style={styles.permissionSubtext}>
          Camera access is required to scan book barcodes
        </Text>
      </View>
    );
  }

  if (!isEnabled) {
    return (
      <View style={styles.disabledContainer}>
        <Camera size={48} color={Colors.neutral[400]} />
        <Text style={styles.permissionText}>Scanner is currently disabled</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.scannerContainer}>
        <BarCodeScanner
          onBarCodeScanned={scanned ? undefined : handleBarCodeScanned}
          style={StyleSheet.absoluteFillObject}
        />
        <View style={styles.overlay}>
          <View style={styles.unfocusedContainer}></View>
          <View style={styles.middleContainer}>
            <View style={styles.unfocusedContainer}></View>
            <View style={styles.focusedContainer}>
              <View style={styles.cornerTopLeft} />
              <View style={styles.cornerTopRight} />
              <View style={styles.cornerBottomLeft} />
              <View style={styles.cornerBottomRight} />
            </View>
            <View style={styles.unfocusedContainer}></View>
          </View>
          <View style={styles.unfocusedContainer}></View>
        </View>
      </View>
      
      {scanned && (
        <View style={styles.scanAgainContainer}>
          <Button
            title="Scan Again"
            onPress={handleScanAgain}
            variant="primary"
          />
        </View>
      )}
      
      <View style={styles.instructionsContainer}>
        <Text style={styles.instructionsText}>
          Position the barcode within the frame
        </Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    overflow: 'hidden',
    borderRadius: Theme.borderRadius.md,
  },
  scannerContainer: {
    width: '100%',
    height: '100%',
    overflow: 'hidden',
    borderRadius: Theme.borderRadius.md,
  },
  permissionContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: Colors.neutral[100],
    padding: Theme.spacing.lg,
    borderRadius: Theme.borderRadius.md,
  },
  permissionText: {
    fontSize: Theme.fontSizes.md,
    fontFamily: Theme.fonts.semiBold,
    color: Colors.neutral[800],
    marginTop: Theme.spacing.md,
    textAlign: 'center',
  },
  permissionSubtext: {
    fontSize: Theme.fontSizes.sm,
    fontFamily: Theme.fonts.regular,
    color: Colors.neutral[600],
    marginTop: Theme.spacing.sm,
    textAlign: 'center',
  },
  disabledContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: Colors.neutral[100],
    padding: Theme.spacing.lg,
    borderRadius: Theme.borderRadius.md,
  },
  overlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
  unfocusedContainer: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.6)',
  },
  middleContainer: {
    flexDirection: 'row',
    height: 250,
  },
  focusedContainer: {
    flex: 6,
  },
  cornerTopLeft: {
    position: 'absolute',
    top: 0,
    left: 0,
    width: 40,
    height: 40,
    borderTopWidth: 3,
    borderLeftWidth: 3,
    borderColor: Colors.white,
  },
  cornerTopRight: {
    position: 'absolute',
    top: 0,
    right: 0,
    width: 40,
    height: 40,
    borderTopWidth: 3,
    borderRightWidth: 3,
    borderColor: Colors.white,
  },
  cornerBottomLeft: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    width: 40,
    height: 40,
    borderBottomWidth: 3,
    borderLeftWidth: 3,
    borderColor: Colors.white,
  },
  cornerBottomRight: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    width: 40,
    height: 40,
    borderBottomWidth: 3,
    borderRightWidth: 3,
    borderColor: Colors.white,
  },
  instructionsContainer: {
    position: 'absolute',
    bottom: 30,
    left: 0,
    right: 0,
    justifyContent: 'center',
    alignItems: 'center',
  },
  instructionsText: {
    color: Colors.white,
    fontSize: Theme.fontSizes.sm,
    fontFamily: Theme.fonts.medium,
    textAlign: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    paddingHorizontal: Theme.spacing.md,
    paddingVertical: Theme.spacing.sm,
    borderRadius: Theme.borderRadius.full,
  },
  scanAgainContainer: {
    position: 'absolute',
    bottom: 80,
    left: 0,
    right: 0,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export default Scanner;