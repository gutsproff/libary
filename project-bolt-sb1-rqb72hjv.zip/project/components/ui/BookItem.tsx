import React from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity } from 'react-native';
import { Book } from '@/types/Book';
import StatusBadge from './StatusBadge';
import Theme from '@/constants/Theme';
import Colors from '@/constants/Colors';
import { ChevronRight } from 'lucide-react-native';

interface BookItemProps {
  book: Book;
  onPress: (book: Book) => void;
}

const BookItem: React.FC<BookItemProps> = ({ book, onPress }) => {
  const handlePress = () => {
    onPress(book);
  };

  return (
    <TouchableOpacity style={styles.container} onPress={handlePress}>
      <View style={styles.imageContainer}>
        <Image
          source={{ uri: book.coverUrl || 'https://images.pexels.com/photos/1766604/pexels-photo-1766604.jpeg' }}
          style={styles.image}
          resizeMode="cover"
        />
      </View>
      <View style={styles.contentContainer}>
        <Text style={styles.title} numberOfLines={2}>
          {book.title}
        </Text>
        <Text style={styles.author} numberOfLines={1}>
          {book.author}
        </Text>
        <View style={styles.footer}>
          <StatusBadge status={book.status as 'available' | 'borrowed'} />
          {book.status === 'borrowed' && book.dueDate && (
            <Text style={styles.dueDate}>
              Due: {new Date(book.dueDate).toLocaleDateString()}
            </Text>
          )}
        </View>
      </View>
      <ChevronRight size={20} color={Colors.neutral[400]} />
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.white,
    borderRadius: Theme.borderRadius.md,
    padding: Theme.spacing.md,
    marginBottom: Theme.spacing.md,
    borderWidth: 1,
    borderColor: Colors.neutral[200],
    ...Theme.shadows.sm,
  },
  imageContainer: {
    width: 60,
    height: 80,
    borderRadius: Theme.borderRadius.sm,
    overflow: 'hidden',
    marginRight: Theme.spacing.md,
  },
  image: {
    width: '100%',
    height: '100%',
  },
  contentContainer: {
    flex: 1,
    justifyContent: 'space-between',
  },
  title: {
    fontSize: Theme.fontSizes.md,
    fontFamily: Theme.fonts.semiBold,
    color: Colors.neutral[800],
    marginBottom: 2,
  },
  author: {
    fontSize: Theme.fontSizes.sm,
    fontFamily: Theme.fonts.regular,
    color: Colors.neutral[600],
    marginBottom: Theme.spacing.sm,
  },
  footer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  dueDate: {
    fontSize: Theme.fontSizes.xs,
    fontFamily: Theme.fonts.medium,
    color: Colors.neutral[500],
  },
});

export default BookItem;