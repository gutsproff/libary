import React, { useState } from 'react';
import { View, Text, StyleSheet, Image, ScrollView, Alert } from 'react-native';
import { Book } from '@/types/Book';
import Colors from '@/constants/Colors';
import Theme from '@/constants/Theme';
import StatusBadge from './StatusBadge';
import Button from './Button';
import Card from './Card';
import { useBooks } from '@/context/BookContext';
import Input from './Input';

interface BookDetailsProps {
  book: Book;
}

const BookDetails: React.FC<BookDetailsProps> = ({ book }) => {
  const { issueBook, returnBook, isLoading } = useBooks();
  const [borrowerId, setBorrowerId] = useState('');
  const [showIssueForm, setShowIssueForm] = useState(false);
  const [borrowerIdError, setBorrowerIdError] = useState('');

  const handleIssue = () => {
    if (book.status === 'available') {
      setShowIssueForm(true);
    } else {
      Alert.alert(
        'Confirm Return',
        'Are you sure you want to return this book?',
        [
          { text: 'Cancel', style: 'cancel' },
          {
            text: 'Return',
            onPress: async () => {
              try {
                await returnBook(book.isbn);
              } catch (error) {
                Alert.alert('Error', 'Failed to return the book. Please try again.');
              }
            },
          },
        ]
      );
    }
  };

  const handleIssueSave = async () => {
    if (!borrowerId.trim()) {
      setBorrowerIdError('Borrower ID is required');
      return;
    }
    
    setBorrowerIdError('');
    
    try {
      await issueBook(book.isbn, borrowerId);
      setShowIssueForm(false);
      setBorrowerId('');
    } catch (error) {
      Alert.alert('Error', 'Failed to issue the book. Please try again.');
    }
  };

  const handleCancelIssue = () => {
    setShowIssueForm(false);
    setBorrowerId('');
    setBorrowerIdError('');
  };

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      <View style={styles.headerContainer}>
        <View style={styles.coverContainer}>
          <Image
            source={{ uri: book.coverUrl || 'https://images.pexels.com/photos/1766604/pexels-photo-1766604.jpeg' }}
            style={styles.coverImage}
            resizeMode="cover"
          />
        </View>
        <View style={styles.infoContainer}>
          <Text style={styles.title}>{book.title}</Text>
          <Text style={styles.author}>by {book.author}</Text>
          <View style={styles.statusContainer}>
            <StatusBadge status={book.status as 'available' | 'borrowed'} />
            {book.status === 'borrowed' && book.dueDate && (
              <Text style={styles.dueDate}>
                Due: {new Date(book.dueDate).toLocaleDateString()}
              </Text>
            )}
          </View>
        </View>
      </View>

      {book.description && (
        <Card style={styles.descriptionCard}>
          <Text style={styles.sectionTitle}>Description</Text>
          <Text style={styles.description}>{book.description}</Text>
        </Card>
      )}

      <Card style={styles.detailsCard}>
        <Text style={styles.sectionTitle}>Book Details</Text>
        <View style={styles.detailRow}>
          <Text style={styles.detailLabel}>ISBN</Text>
          <Text style={styles.detailValue}>{book.isbn}</Text>
        </View>
        {book.publishedDate && (
          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>Published Date</Text>
            <Text style={styles.detailValue}>{book.publishedDate}</Text>
          </View>
        )}
        {book.publisher && (
          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>Publisher</Text>
            <Text style={styles.detailValue}>{book.publisher}</Text>
          </View>
        )}
        {book.pageCount && (
          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>Pages</Text>
            <Text style={styles.detailValue}>{book.pageCount}</Text>
          </View>
        )}
      </Card>

      {book.status === 'borrowed' && book.borrowedBy && (
        <Card style={styles.borrowerCard}>
          <Text style={styles.sectionTitle}>Borrower Information</Text>
          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>Borrower ID</Text>
            <Text style={styles.detailValue}>{book.borrowedBy}</Text>
          </View>
          {book.issuedAt && (
            <View style={styles.detailRow}>
              <Text style={styles.detailLabel}>Issue Date</Text>
              <Text style={styles.detailValue}>
                {new Date(book.issuedAt).toLocaleDateString()}
              </Text>
            </View>
          )}
          {book.dueDate && (
            <View style={styles.detailRow}>
              <Text style={styles.detailLabel}>Due Date</Text>
              <Text style={styles.detailValue}>
                {new Date(book.dueDate).toLocaleDateString()}
              </Text>
            </View>
          )}
        </Card>
      )}

      {showIssueForm ? (
        <Card style={styles.issueCard}>
          <Text style={styles.sectionTitle}>Issue Book</Text>
          <Input
            label="Borrower ID"
            placeholder="Enter borrower ID"
            value={borrowerId}
            onChangeText={setBorrowerId}
            error={borrowerIdError}
          />
          <View style={styles.buttonRow}>
            <Button
              title="Cancel"
              onPress={handleCancelIssue}
              variant="outline"
              style={styles.cancelButton}
            />
            <Button
              title="Issue Book"
              onPress={handleIssueSave}
              variant="primary"
              isLoading={isLoading}
              style={styles.saveButton}
            />
          </View>
        </Card>
      ) : (
        <Button
          title={book.status === 'available' ? 'Issue Book' : 'Return Book'}
          onPress={handleIssue}
          variant={book.status === 'available' ? 'primary' : 'secondary'}
          isLoading={isLoading}
          style={styles.actionButton}
        />
      )}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.neutral[50],
  },
  headerContainer: {
    flexDirection: 'row',
    padding: Theme.spacing.md,
    backgroundColor: Colors.white,
    borderBottomWidth: 1,
    borderBottomColor: Colors.neutral[200],
    ...Theme.shadows.sm,
  },
  coverContainer: {
    width: 100,
    height: 150,
    borderRadius: Theme.borderRadius.sm,
    overflow: 'hidden',
    ...Theme.shadows.sm,
  },
  coverImage: {
    width: '100%',
    height: '100%',
  },
  infoContainer: {
    flex: 1,
    marginLeft: Theme.spacing.md,
    justifyContent: 'space-between',
  },
  title: {
    fontSize: Theme.fontSizes.xl,
    fontFamily: Theme.fonts.bold,
    color: Colors.neutral[900],
    marginBottom: Theme.spacing.xs,
  },
  author: {
    fontSize: Theme.fontSizes.md,
    fontFamily: Theme.fonts.regular,
    color: Colors.neutral[600],
    marginBottom: Theme.spacing.sm,
  },
  statusContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  dueDate: {
    fontSize: Theme.fontSizes.sm,
    fontFamily: Theme.fonts.medium,
    color: Colors.warning[600],
  },
  descriptionCard: {
    marginTop: Theme.spacing.md,
    marginHorizontal: Theme.spacing.md,
  },
  description: {
    fontSize: Theme.fontSizes.md,
    fontFamily: Theme.fonts.regular,
    color: Colors.neutral[700],
    lineHeight: 22,
  },
  detailsCard: {
    marginTop: Theme.spacing.md,
    marginHorizontal: Theme.spacing.md,
  },
  borrowerCard: {
    marginTop: Theme.spacing.md,
    marginHorizontal: Theme.spacing.md,
  },
  issueCard: {
    marginTop: Theme.spacing.md,
    marginHorizontal: Theme.spacing.md,
    marginBottom: Theme.spacing.xl,
  },
  sectionTitle: {
    fontSize: Theme.fontSizes.lg,
    fontFamily: Theme.fonts.semiBold,
    color: Colors.neutral[800],
    marginBottom: Theme.spacing.md,
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: Theme.spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: Colors.neutral[200],
  },
  detailLabel: {
    fontSize: Theme.fontSizes.md,
    fontFamily: Theme.fonts.medium,
    color: Colors.neutral[700],
  },
  detailValue: {
    fontSize: Theme.fontSizes.md,
    fontFamily: Theme.fonts.regular,
    color: Colors.neutral[900],
  },
  actionButton: {
    marginHorizontal: Theme.spacing.md,
    marginTop: Theme.spacing.md,
    marginBottom: Theme.spacing.xl,
  },
  buttonRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: Theme.spacing.md,
  },
  cancelButton: {
    flex: 1,
    marginRight: Theme.spacing.sm,
  },
  saveButton: {
    flex: 1,
    marginLeft: Theme.spacing.sm,
  },
});

export default BookDetails;