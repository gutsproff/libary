import React from 'react';
import { View, Text, StyleSheet, ViewStyle } from 'react-native';
import Colors from '@/constants/Colors';
import Theme from '@/constants/Theme';

type StatusType = 'available' | 'borrowed' | 'processing' | 'error';

interface StatusBadgeProps {
  status: StatusType;
  style?: ViewStyle;
}

const StatusBadge: React.FC<StatusBadgeProps> = ({ status, style }) => {
  const getStatusStyle = () => {
    switch (status) {
      case 'available':
        return {
          backgroundColor: Colors.success[50],
          textColor: Colors.success[700],
          borderColor: Colors.success[200],
        };
      case 'borrowed':
        return {
          backgroundColor: Colors.warning[50],
          textColor: Colors.warning[700],
          borderColor: Colors.warning[200],
        };
      case 'processing':
        return {
          backgroundColor: Colors.primary[50],
          textColor: Colors.primary[700],
          borderColor: Colors.primary[200],
        };
      case 'error':
        return {
          backgroundColor: Colors.error[50],
          textColor: Colors.error[700],
          borderColor: Colors.error[200],
        };
      default:
        return {
          backgroundColor: Colors.neutral[50],
          textColor: Colors.neutral[700],
          borderColor: Colors.neutral[200],
        };
    }
  };

  const getStatusText = () => {
    switch (status) {
      case 'available':
        return 'Available';
      case 'borrowed':
        return 'Borrowed';
      case 'processing':
        return 'Processing';
      case 'error':
        return 'Error';
      default:
        return 'Unknown';
    }
  };

  const statusStyle = getStatusStyle();

  return (
    <View
      style={[
        styles.badge,
        {
          backgroundColor: statusStyle.backgroundColor,
          borderColor: statusStyle.borderColor,
        },
        style,
      ]}
    >
      <Text
        style={[
          styles.badgeText,
          {
            color: statusStyle.textColor,
          },
        ]}
      >
        {getStatusText()}
      </Text>
    </View>
  );
};

const styles = StyleSheet.create({
  badge: {
    paddingHorizontal: Theme.spacing.sm,
    paddingVertical: Theme.spacing.xs,
    borderRadius: Theme.borderRadius.full,
    borderWidth: 1,
    alignSelf: 'flex-start',
  },
  badgeText: {
    fontSize: Theme.fontSizes.xs,
    fontFamily: Theme.fonts.medium,
  },
});

export default StatusBadge;