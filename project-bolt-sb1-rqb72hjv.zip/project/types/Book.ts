export interface Book {
  isbn: string;
  title: string;
  author: string;
  coverUrl?: string;
  publishedDate?: string;
  publisher?: string;
  pageCount?: number;
  categories?: string[];
  description?: string;
  status: 'available' | 'borrowed';
  issuedAt?: string;
  dueDate?: string;
  borrowedBy?: string;
}

export interface BookSearchResult {
  isbn: string;
  title: string;
  author: string;
  coverUrl?: string;
}