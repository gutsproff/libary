import React, { createContext, useState, useEffect, useContext } from 'react';
import { AuthState, LoginCredentials, User } from '@/types/User';
import { authService } from '@/services/authService';
import { router } from 'expo-router';

interface AuthContextType extends AuthState {
  login: (credentials: LoginCredentials) => Promise<void>;
  logout: () => void;
  clearError: () => void;
}

// Mock user for development purposes
const MOCK_USER: User = {
  id: '1',
  name: 'John Librarian',
  email: 'librarian@library.com',
  role: 'librarian',
  profilePicture: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg',
};

const initialState: AuthState = {
  user: null,
  isAuthenticated: false,
  isLoading: true,
  error: null,
};

const AuthContext = createContext<AuthContextType>({
  ...initialState,
  login: async () => {},
  logout: () => {},
  clearError: () => {},
});

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, setState] = useState<AuthState>(initialState);

  useEffect(() => {
    const checkAuthStatus = async () => {
      try {
        // In a real app, we would check localStorage/AsyncStorage for a token
        // and validate it with the backend
        
        // For demo purposes, let's just set the mock user
        // Comment out for production or when connecting to a real backend
        setState({
          user: MOCK_USER,
          isAuthenticated: true,
          isLoading: false,
          error: null,
        });
        
        // Uncomment this for production use
        /*
        const user = await authService.getCurrentUser();
        setState({
          user,
          isAuthenticated: !!user,
          isLoading: false,
          error: null,
        });
        */
      } catch (error) {
        setState({
          user: null,
          isAuthenticated: false,
          isLoading: false,
          error: 'Failed to restore authentication state',
        });
      }
    };

    checkAuthStatus();
  }, []);

  const login = async (credentials: LoginCredentials) => {
    setState({ ...state, isLoading: true, error: null });
    try {
      // In a real app, we would call authService.login()
      // For demo purposes, let's just set the mock user
      
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setState({
        user: MOCK_USER,
        isAuthenticated: true,
        isLoading: false,
        error: null,
      });
      
      router.replace('/(tabs)');
    } catch (error) {
      setState({
        ...state,
        isLoading: false,
        error: 'Invalid email or password',
      });
    }
  };

  const logout = () => {
    // In a real app, we would call authService.logout()
    setState({
      user: null,
      isAuthenticated: false,
      isLoading: false,
      error: null,
    });
    
    router.replace('/(auth)');
  };

  const clearError = () => {
    setState({ ...state, error: null });
  };

  return (
    <AuthContext.Provider
      value={{
        ...state,
        login,
        logout,
        clearError,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);