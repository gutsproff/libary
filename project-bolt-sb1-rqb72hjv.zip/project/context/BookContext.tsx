import React, { createContext, useState, useContext } from 'react';
import { Book } from '@/types/Book';
import { bookService } from '@/services/bookService';

interface BookContextType {
  books: Book[];
  currentBook: Book | null;
  isLoading: boolean;
  error: string | null;
  fetchBooks: () => Promise<void>;
  fetchBookByIsbn: (isbn: string) => Promise<Book | null>;
  issueBook: (isbn: string, borrowerId: string) => Promise<void>;
  returnBook: (isbn: string) => Promise<void>;
  clearCurrentBook: () => void;
  clearError: () => void;
}

// Mock books for development purposes
const MOCK_BOOKS: Book[] = [
  {
    isbn: '9780735211292',
    title: 'Atomic Habits',
    author: 'James Clear',
    coverUrl: 'https://images.pexels.com/photos/2465877/pexels-photo-2465877.jpeg',
    publishedDate: '2018-10-16',
    publisher: 'Avery',
    pageCount: 320,
    status: 'available',
    description: 'An Easy & Proven Way to Build Good Habits & Break Bad Ones'
  },
  {
    isbn: '9781451673319',
    title: 'The 7 Habits of Highly Effective People',
    author: 'Stephen R. Covey',
    coverUrl: 'https://images.pexels.com/photos/5834351/pexels-photo-5834351.jpeg',
    publishedDate: '2013-11-19',
    publisher: 'Simon & Schuster',
    pageCount: 432,
    status: 'borrowed',
    borrowedBy: 'Alex Johnson',
    issuedAt: '2023-06-01',
    dueDate: '2023-06-15',
    description: 'Powerful Lessons in Personal Change'
  },
  {
    isbn: '9780593139134',
    title: 'Think Again',
    author: 'Adam Grant',
    coverUrl: 'https://images.pexels.com/photos/590493/pexels-photo-590493.jpeg',
    publishedDate: '2021-02-02',
    publisher: 'Viking',
    pageCount: 320,
    status: 'available',
    description: 'The Power of Knowing What You Don\'t Know'
  }
];

const initialState = {
  books: [] as Book[],
  currentBook: null as Book | null,
  isLoading: false,
  error: null as string | null,
};

const BookContext = createContext<BookContextType>({
  ...initialState,
  fetchBooks: async () => {},
  fetchBookByIsbn: async () => null,
  issueBook: async () => {},
  returnBook: async () => {},
  clearCurrentBook: () => {},
  clearError: () => {},
});

export const BookProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, setState] = useState(initialState);

  const fetchBooks = async () => {
    setState({ ...state, isLoading: true, error: null });
    try {
      // In a real app, we would call bookService.getBooks()
      // For demo purposes, let's just use mock data
      
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setState({
        ...state,
        books: MOCK_BOOKS,
        isLoading: false,
      });
    } catch (error) {
      setState({
        ...state,
        isLoading: false,
        error: 'Failed to fetch books',
      });
    }
  };

  const fetchBookByIsbn = async (isbn: string): Promise<Book | null> => {
    setState({ ...state, isLoading: true, error: null });
    try {
      // In a real app, we would call bookService.getBookByIsbn(isbn)
      // For demo purposes, let's use mock data
      
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const book = MOCK_BOOKS.find(b => b.isbn === isbn) || null;
      
      setState({
        ...state,
        currentBook: book,
        isLoading: false,
      });
      
      return book;
    } catch (error) {
      setState({
        ...state,
        isLoading: false,
        error: 'Failed to fetch book details',
      });
      return null;
    }
  };

  const issueBook = async (isbn: string, borrowerId: string) => {
    setState({ ...state, isLoading: true, error: null });
    try {
      // In a real app, we would call bookService.issueBook(isbn, borrowerId)
      // For demo purposes, let's simulate the API call
      
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Update the current book and books list
      const updatedBooks = state.books.map(book => 
        book.isbn === isbn 
          ? { 
              ...book, 
              status: 'borrowed', 
              borrowedBy: borrowerId,
              issuedAt: new Date().toISOString(),
              dueDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString() // 14 days from now
            } as Book
          : book
      );
      
      const updatedCurrentBook = state.currentBook?.isbn === isbn 
        ? { 
            ...state.currentBook, 
            status: 'borrowed', 
            borrowedBy: borrowerId,
            issuedAt: new Date().toISOString(),
            dueDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString() // 14 days from now
          } 
        : state.currentBook;
      
      setState({
        ...state,
        books: updatedBooks,
        currentBook: updatedCurrentBook,
        isLoading: false,
      });
    } catch (error) {
      setState({
        ...state,
        isLoading: false,
        error: 'Failed to issue book',
      });
    }
  };

  const returnBook = async (isbn: string) => {
    setState({ ...state, isLoading: true, error: null });
    try {
      // In a real app, we would call bookService.returnBook(isbn)
      // For demo purposes, let's simulate the API call
      
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Update the current book and books list
      const updatedBooks = state.books.map(book => 
        book.isbn === isbn 
          ? { 
              ...book, 
              status: 'available', 
              borrowedBy: undefined,
              issuedAt: undefined,
              dueDate: undefined 
            } as Book
          : book
      );
      
      const updatedCurrentBook = state.currentBook?.isbn === isbn 
        ? { 
            ...state.currentBook, 
            status: 'available', 
            borrowedBy: undefined,
            issuedAt: undefined,
            dueDate: undefined 
          } 
        : state.currentBook;
      
      setState({
        ...state,
        books: updatedBooks,
        currentBook: updatedCurrentBook,
        isLoading: false,
      });
    } catch (error) {
      setState({
        ...state,
        isLoading: false,
        error: 'Failed to return book',
      });
    }
  };

  const clearCurrentBook = () => {
    setState({ ...state, currentBook: null });
  };

  const clearError = () => {
    setState({ ...state, error: null });
  };

  return (
    <BookContext.Provider
      value={{
        ...state,
        fetchBooks,
        fetchBookByIsbn,
        issueBook,
        returnBook,
        clearCurrentBook,
        clearError,
      }}
    >
      {children}
    </BookContext.Provider>
  );
};

export const useBooks = () => useContext(BookContext);