import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Image, KeyboardAvoidingView, Platform, ScrollView } from 'react-native';
import { router } from 'expo-router';
import Input from '@/components/ui/Input';
import Button from '@/components/ui/Button';
import Colors from '@/constants/Colors';
import Theme from '@/constants/Theme';
import { useAuth } from '@/context/AuthContext';
import { Book, Lock } from 'lucide-react-native';

export default function LoginScreen() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [emailError, setEmailError] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const { login, isAuthenticated, isLoading, error } = useAuth();

  useEffect(() => {
    if (isAuthenticated) {
      router.replace('/(tabs)');
    }
  }, [isAuthenticated]);

  const validateEmail = (email: string) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email) {
      setEmailError('Email is required');
      return false;
    } else if (!emailRegex.test(email)) {
      setEmailError('Please enter a valid email address');
      return false;
    }
    setEmailError('');
    return true;
  };

  const validatePassword = (password: string) => {
    if (!password) {
      setPasswordError('Password is required');
      return false;
    } else if (password.length < 6) {
      setPasswordError('Password must be at least 6 characters');
      return false;
    }
    setPasswordError('');
    return true;
  };

  const handleLogin = async () => {
    const isEmailValid = validateEmail(email);
    const isPasswordValid = validatePassword(password);

    if (isEmailValid && isPasswordValid) {
      await login({ email, password });
    }
  };

  // For demo purposes, automatically fill in the login form
  useEffect(() => {
    // Pre-fill the demo credentials
    setEmail('librarian@library.com');
    setPassword('password123');
  }, []);

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      keyboardVerticalOffset={Platform.OS === 'ios' ? 50 : 0}
    >
      <ScrollView
        contentContainerStyle={styles.scrollContainer}
        keyboardShouldPersistTaps="handled"
      >
        <View style={styles.logoContainer}>
          <View style={styles.logoCircle}>
            <Book size={48} color={Colors.primary[700]} />
          </View>
          <Text style={styles.logoText}>Library Scanner</Text>
          <Text style={styles.logoSubtext}>Manage your library with ease</Text>
        </View>

        <View style={styles.formContainer}>
          <Text style={styles.welcomeText}>Welcome Back</Text>
          <Text style={styles.subtitleText}>
            Sign in to continue managing your library
          </Text>

          {error && (
            <View style={styles.errorContainer}>
              <Text style={styles.errorText}>{error}</Text>
            </View>
          )}

          <Input
            label="Email"
            placeholder="Enter your email"
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
            error={emailError}
            leftIcon={<Book size={20} color={Colors.neutral[500]} />}
          />

          <Input
            label="Password"
            placeholder="Enter your password"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
            error={passwordError}
            leftIcon={<Lock size={20} color={Colors.neutral[500]} />}
          />

          <Button
            title="Sign In"
            onPress={handleLogin}
            isLoading={isLoading}
            style={styles.loginButton}
          />

          <Text style={styles.demoText}>
            This is a demo app. Use any email and password to sign in.
          </Text>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  scrollContainer: {
    flexGrow: 1,
    justifyContent: 'center',
    padding: Theme.spacing.lg,
  },
  logoContainer: {
    alignItems: 'center',
    marginBottom: Theme.spacing.xl,
  },
  logoCircle: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: Colors.primary[50],
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: Theme.spacing.md,
    ...Theme.shadows.md,
  },
  logoText: {
    fontSize: Theme.fontSizes['3xl'],
    fontFamily: Theme.fonts.bold,
    color: Colors.primary[700],
    marginBottom: Theme.spacing.xs,
  },
  logoSubtext: {
    fontSize: Theme.fontSizes.md,
    fontFamily: Theme.fonts.regular,
    color: Colors.neutral[600],
  },
  formContainer: {
    width: '100%',
  },
  welcomeText: {
    fontSize: Theme.fontSizes['2xl'],
    fontFamily: Theme.fonts.bold,
    color: Colors.neutral[900],
    marginBottom: Theme.spacing.xs,
  },
  subtitleText: {
    fontSize: Theme.fontSizes.md,
    fontFamily: Theme.fonts.regular,
    color: Colors.neutral[600],
    marginBottom: Theme.spacing.lg,
  },
  errorContainer: {
    backgroundColor: Colors.error[50],
    borderRadius: Theme.borderRadius.md,
    padding: Theme.spacing.md,
    marginBottom: Theme.spacing.md,
    borderWidth: 1,
    borderColor: Colors.error[200],
  },
  errorText: {
    color: Colors.error[700],
    fontFamily: Theme.fonts.medium,
    fontSize: Theme.fontSizes.sm,
  },
  loginButton: {
    marginTop: Theme.spacing.md,
  },
  demoText: {
    fontSize: Theme.fontSizes.sm,
    fontFamily: Theme.fonts.regular,
    color: Colors.neutral[500],
    textAlign: 'center',
    marginTop: Theme.spacing.xl,
  },
});