import React, { useEffect } from 'react';
import { View, StyleSheet, ActivityIndicator, Text } from 'react-native';
import { useLocalSearchParams, Stack } from 'expo-router';
import { useBooks } from '@/context/BookContext';
import BookDetails from '@/components/ui/BookDetails';
import Colors from '@/constants/Colors';
import Theme from '@/constants/Theme';

export default function BookDetailsScreen() {
  const { isbn } = useLocalSearchParams<{ isbn: string }>();
  const { fetchBookByIsbn, currentBook, isLoading, error } = useBooks();

  useEffect(() => {
    if (isbn) {
      fetchBookByIsbn(isbn);
    }
  }, [isbn]);

  return (
    <>
      <Stack.Screen
        options={{
          headerTitle: 'Book Details',
          headerShown: true,
        }}
      />
      <View style={styles.container}>
        {isLoading ? (
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color={Colors.primary[700]} />
            <Text style={styles.loadingText}>Loading book details...</Text>
          </View>
        ) : error ? (
          <View style={styles.errorContainer}>
            <Text style={styles.errorTitle}>Error</Text>
            <Text style={styles.errorText}>{error}</Text>
          </View>
        ) : currentBook ? (
          <BookDetails book={currentBook} />
        ) : (
          <View style={styles.notFoundContainer}>
            <Text style={styles.notFoundTitle}>Book Not Found</Text>
            <Text style={styles.notFoundText}>
              The book with ISBN {isbn} was not found in the library.
            </Text>
          </View>
        )}
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.neutral[50],
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: Theme.spacing.md,
    fontSize: Theme.fontSizes.md,
    fontFamily: Theme.fonts.medium,
    color: Colors.neutral[700],
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: Theme.spacing.xl,
  },
  errorTitle: {
    fontSize: Theme.fontSizes.xl,
    fontFamily: Theme.fonts.bold,
    color: Colors.error[700],
    marginBottom: Theme.spacing.md,
  },
  errorText: {
    fontSize: Theme.fontSizes.md,
    fontFamily: Theme.fonts.regular,
    color: Colors.neutral[700],
    textAlign: 'center',
  },
  notFoundContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: Theme.spacing.xl,
  },
  notFoundTitle: {
    fontSize: Theme.fontSizes.xl,
    fontFamily: Theme.fonts.bold,
    color: Colors.neutral[800],
    marginBottom: Theme.spacing.md,
  },
  notFoundText: {
    fontSize: Theme.fontSizes.md,
    fontFamily: Theme.fonts.regular,
    color: Colors.neutral[600],
    textAlign: 'center',
  },
});