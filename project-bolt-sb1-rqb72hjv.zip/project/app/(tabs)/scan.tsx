import React, { useState, useRef } from 'react';
import { View, Text, StyleSheet, Alert, TextInput, TouchableOpacity } from 'react-native';
import { router } from 'expo-router';
import Scanner from '@/components/ui/Scanner';
import Colors from '@/constants/Colors';
import Theme from '@/constants/Theme';
import { useBooks } from '@/context/BookContext';
import Button from '@/components/ui/Button';
import { Book, ShieldAlert } from 'lucide-react-native';

export default function ScanScreen() {
  const [manualIsbn, setManualIsbn] = useState('');
  const [isManualEntry, setIsManualEntry] = useState(false);
  const [isbnError, setIsbnError] = useState('');
  const { fetchBookByIsbn, isLoading } = useBooks();
  const inputRef = useRef<TextInput>(null);

  const validateIsbn = (isbn: string): boolean => {
    const cleanIsbn = isbn.replace(/-/g, '').replace(/\s/g, '');
    
    // Check if it's a valid ISBN-10 or ISBN-13
    const isIsbn10 = /^(?:\d[- ]?){9}[\dXx]$/.test(cleanIsbn);
    const isIsbn13 = /^(?:\d[- ]?){13}$/.test(cleanIsbn);
    
    if (!cleanIsbn) {
      setIsbnError('ISBN is required');
      return false;
    } else if (!isIsbn10 && !isIsbn13) {
      setIsbnError('Please enter a valid ISBN-10 or ISBN-13');
      return false;
    }
    
    setIsbnError('');
    return true;
  };

  const handleScan = async (isbn: string) => {
    try {
      const book = await fetchBookByIsbn(isbn);
      
      if (book) {
        router.push(`/books/${isbn}`);
      } else {
        Alert.alert(
          'Book Not Found',
          'This book is not in the library database. Would you like to add it?',
          [
            { text: 'Cancel', style: 'cancel' },
            { 
              text: 'Add Book', 
              onPress: () => {
                // In a real app, this would navigate to an "Add Book" form
                Alert.alert('Feature Coming Soon', 'Book addition will be available in a future update.');
              } 
            }
          ]
        );
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to fetch book information. Please try again.');
    }
  };

  const handleManualEntry = async () => {
    if (validateIsbn(manualIsbn)) {
      await handleScan(manualIsbn.replace(/-/g, '').replace(/\s/g, ''));
    }
  };

  const toggleEntryMode = () => {
    setIsManualEntry(!isManualEntry);
    setManualIsbn('');
    setIsbnError('');
    
    // Focus on the text input when switching to manual mode
    if (!isManualEntry) {
      setTimeout(() => {
        inputRef.current?.focus();
      }, 100);
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.contentContainer}>
        {isManualEntry ? (
          <View style={styles.manualEntryContainer}>
            <View style={styles.iconContainer}>
              <Book size={48} color={Colors.primary[600]} />
            </View>
            <Text style={styles.manualEntryTitle}>Enter ISBN</Text>
            <Text style={styles.manualEntrySubtitle}>
              Type the ISBN code manually
            </Text>
            
            <View style={styles.isbnInputContainer}>
              <TextInput
                ref={inputRef}
                style={[
                  styles.isbnInput,
                  isbnError ? styles.isbnInputError : null,
                ]}
                placeholder="Enter ISBN-10 or ISBN-13"
                value={manualIsbn}
                onChangeText={setManualIsbn}
                keyboardType="number-pad"
                autoCapitalize="none"
                maxLength={17}
              />
              {isbnError ? (
                <View style={styles.errorContainer}>
                  <ShieldAlert size={16} color={Colors.error[500]} />
                  <Text style={styles.errorText}>{isbnError}</Text>
                </View>
              ) : null}
            </View>
            
            <Button
              title="Search"
              onPress={handleManualEntry}
              isLoading={isLoading}
              style={styles.searchButton}
            />
          </View>
        ) : (
          <View style={styles.scannerContainer}>
            <Text style={styles.scannerTitle}>Scan Book Barcode</Text>
            <Text style={styles.scannerSubtitle}>
              Position the barcode within the frame
            </Text>
            <View style={styles.scannerWrapper}>
              <Scanner onScan={handleScan} isEnabled={!isLoading} />
            </View>
          </View>
        )}
      </View>
      
      <View style={styles.footerContainer}>
        <Button
          title={isManualEntry ? "Switch to Scanner" : "Enter ISBN Manually"}
          onPress={toggleEntryMode}
          variant="outline"
          style={styles.switchButton}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.white,
    paddingHorizontal: Theme.spacing.md,
    paddingTop: Theme.spacing.md,
  },
  contentContainer: {
    flex: 1,
    justifyContent: 'center',
  },
  scannerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  scannerTitle: {
    fontSize: Theme.fontSizes.xl,
    fontFamily: Theme.fonts.bold,
    color: Colors.neutral[900],
    marginBottom: Theme.spacing.xs,
    textAlign: 'center',
  },
  scannerSubtitle: {
    fontSize: Theme.fontSizes.md,
    fontFamily: Theme.fonts.regular,
    color: Colors.neutral[600],
    marginBottom: Theme.spacing.xl,
    textAlign: 'center',
  },
  scannerWrapper: {
    width: '100%',
    height: 400,
    overflow: 'hidden',
    borderRadius: Theme.borderRadius.lg,
    ...Theme.shadows.md,
  },
  manualEntryContainer: {
    padding: Theme.spacing.lg,
    alignItems: 'center',
  },
  iconContainer: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: Colors.primary[50],
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: Theme.spacing.md,
  },
  manualEntryTitle: {
    fontSize: Theme.fontSizes.xl,
    fontFamily: Theme.fonts.bold,
    color: Colors.neutral[900],
    marginBottom: Theme.spacing.xs,
  },
  manualEntrySubtitle: {
    fontSize: Theme.fontSizes.md,
    fontFamily: Theme.fonts.regular,
    color: Colors.neutral[600],
    marginBottom: Theme.spacing.xl,
    textAlign: 'center',
  },
  isbnInputContainer: {
    width: '100%',
    marginBottom: Theme.spacing.md,
  },
  isbnInput: {
    width: '100%',
    height: 50,
    borderWidth: 1,
    borderColor: Colors.neutral[300],
    borderRadius: Theme.borderRadius.md,
    paddingHorizontal: Theme.spacing.md,
    fontSize: Theme.fontSizes.md,
    fontFamily: Theme.fonts.regular,
  },
  isbnInputError: {
    borderColor: Colors.error[500],
  },
  errorContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: Theme.spacing.xs,
  },
  errorText: {
    fontSize: Theme.fontSizes.sm,
    fontFamily: Theme.fonts.regular,
    color: Colors.error[600],
    marginLeft: Theme.spacing.xs,
  },
  searchButton: {
    width: '100%',
  },
  footerContainer: {
    padding: Theme.spacing.md,
    paddingBottom: Theme.spacing.xl,
  },
  switchButton: {
    width: '100%',
  },
});