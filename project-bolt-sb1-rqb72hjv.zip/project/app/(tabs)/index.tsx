import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, ActivityIndicator } from 'react-native';
import { useBooks } from '@/context/BookContext';
import { useAuth } from '@/context/AuthContext';
import Colors from '@/constants/Colors';
import Theme from '@/constants/Theme';
import Button from '@/components/ui/Button';
import Card from '@/components/ui/Card';
import { Book } from '@/types/Book';
import { router } from 'expo-router';
import { BookOpen, QrCode, Clock, User } from 'lucide-react-native';

export default function DashboardScreen() {
  const { books, fetchBooks, isLoading } = useBooks();
  const { user } = useAuth();
  const [recentlyBorrowed, setRecentlyBorrowed] = useState<Book[]>([]);
  const [dueSoon, setDueSoon] = useState<Book[]>([]);
  const [stats, setStats] = useState({
    total: 0,
    available: 0,
    borrowed: 0,
  });

  useEffect(() => {
    fetchBooks();
  }, []);

  useEffect(() => {
    if (books.length > 0) {
      // Calculate statistics
      const totalBooks = books.length;
      const availableBooks = books.filter(book => book.status === 'available').length;
      const borrowedBooks = books.filter(book => book.status === 'borrowed').length;
      
      setStats({
        total: totalBooks,
        available: availableBooks,
        borrowed: borrowedBooks,
      });
      
      // Get recently borrowed books
      const borrowed = books
        .filter(book => book.status === 'borrowed' && book.issuedAt)
        .sort((a, b) => {
          const dateA = a.issuedAt ? new Date(a.issuedAt).getTime() : 0;
          const dateB = b.issuedAt ? new Date(b.issuedAt).getTime() : 0;
          return dateB - dateA;
        })
        .slice(0, 3);
      
      setRecentlyBorrowed(borrowed);
      
      // Get books due soon
      const now = new Date();
      const twoWeeksFromNow = new Date(now.getTime() + 14 * 24 * 60 * 60 * 1000);
      
      const due = books
        .filter(book => {
          if (book.status !== 'borrowed' || !book.dueDate) return false;
          
          const dueDate = new Date(book.dueDate);
          return dueDate <= twoWeeksFromNow && dueDate >= now;
        })
        .sort((a, b) => {
          const dateA = a.dueDate ? new Date(a.dueDate).getTime() : 0;
          const dateB = b.dueDate ? new Date(b.dueDate).getTime() : 0;
          return dateA - dateB;
        })
        .slice(0, 3);
      
      setDueSoon(due);
    }
  }, [books]);

  if (isLoading && books.length === 0) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={Colors.primary[700]} />
        <Text style={styles.loadingText}>Loading library data...</Text>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.contentContainer}>
      <View style={styles.header}>
        <View>
          <Text style={styles.welcomeText}>
            Welcome back, {user?.name.split(' ')[0] || 'Librarian'}
          </Text>
          <Text style={styles.subtitleText}>
            Here's an overview of your library
          </Text>
        </View>
        <Button
          title="Scan Book"
          onPress={() => router.push('/(tabs)/scan')}
          variant="primary"
          icon={<QrCode size={16} color={Colors.white} />}
        />
      </View>

      <View style={styles.statsContainer}>
        <Card style={styles.statCard}>
          <View style={[styles.statIconContainer, { backgroundColor: Colors.primary[50] }]}>
            <BookOpen size={24} color={Colors.primary[700]} />
          </View>
          <Text style={styles.statValue}>{stats.total}</Text>
          <Text style={styles.statLabel}>Total Books</Text>
        </Card>
        
        <Card style={styles.statCard}>
          <View style={[styles.statIconContainer, { backgroundColor: Colors.success[50] }]}>
            <BookOpen size={24} color={Colors.success[700]} />
          </View>
          <Text style={styles.statValue}>{stats.available}</Text>
          <Text style={styles.statLabel}>Available</Text>
        </Card>
        
        <Card style={styles.statCard}>
          <View style={[styles.statIconContainer, { backgroundColor: Colors.warning[50] }]}>
            <Clock size={24} color={Colors.warning[700]} />
          </View>
          <Text style={styles.statValue}>{stats.borrowed}</Text>
          <Text style={styles.statLabel}>Borrowed</Text>
        </Card>
      </View>

      <View style={styles.sectionContainer}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Recently Borrowed</Text>
          <Button
            title="View All"
            onPress={() => router.push('/(tabs)/books')}
            variant="outline"
            size="sm"
          />
        </View>
        
        {recentlyBorrowed.length > 0 ? (
          recentlyBorrowed.map(book => (
            <Card key={book.isbn} style={styles.bookCard}>
              <View style={styles.bookCardContent}>
                <View style={styles.bookInfo}>
                  <Text style={styles.bookTitle} numberOfLines={1}>
                    {book.title}
                  </Text>
                  <Text style={styles.bookAuthor} numberOfLines={1}>
                    by {book.author}
                  </Text>
                  {book.borrowedBy && (
                    <View style={styles.borrowerContainer}>
                      <User size={14} color={Colors.neutral[500]} />
                      <Text style={styles.borrowerText}>{book.borrowedBy}</Text>
                    </View>
                  )}
                </View>
                {book.dueDate && (
                  <View style={styles.dueDateContainer}>
                    <Text style={styles.dueDateLabel}>Due:</Text>
                    <Text style={styles.dueDateText}>
                      {new Date(book.dueDate).toLocaleDateString()}
                    </Text>
                  </View>
                )}
              </View>
            </Card>
          ))
        ) : (
          <Text style={styles.emptyText}>No books have been borrowed recently.</Text>
        )}
      </View>

      <View style={styles.sectionContainer}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Due Soon</Text>
          <Button
            title="View All"
            onPress={() => router.push('/(tabs)/books')}
            variant="outline"
            size="sm"
          />
        </View>
        
        {dueSoon.length > 0 ? (
          dueSoon.map(book => (
            <Card key={book.isbn} style={styles.bookCard}>
              <View style={styles.bookCardContent}>
                <View style={styles.bookInfo}>
                  <Text style={styles.bookTitle} numberOfLines={1}>
                    {book.title}
                  </Text>
                  <Text style={styles.bookAuthor} numberOfLines={1}>
                    by {book.author}
                  </Text>
                  {book.borrowedBy && (
                    <View style={styles.borrowerContainer}>
                      <User size={14} color={Colors.neutral[500]} />
                      <Text style={styles.borrowerText}>{book.borrowedBy}</Text>
                    </View>
                  )}
                </View>
                {book.dueDate && (
                  <View style={styles.dueDateContainer}>
                    <Text style={styles.dueDateLabel}>Due:</Text>
                    <Text style={[
                      styles.dueDateText,
                      new Date(book.dueDate) <= new Date() && styles.overdue
                    ]}>
                      {new Date(book.dueDate).toLocaleDateString()}
                    </Text>
                  </View>
                )}
              </View>
            </Card>
          ))
        ) : (
          <Text style={styles.emptyText}>No books are due soon.</Text>
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.neutral[50],
  },
  contentContainer: {
    padding: Theme.spacing.md,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: Theme.spacing.md,
    fontSize: Theme.fontSizes.md,
    fontFamily: Theme.fonts.medium,
    color: Colors.neutral[700],
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: Theme.spacing.lg,
  },
  welcomeText: {
    fontSize: Theme.fontSizes.xl,
    fontFamily: Theme.fonts.bold,
    color: Colors.neutral[900],
  },
  subtitleText: {
    fontSize: Theme.fontSizes.md,
    fontFamily: Theme.fonts.regular,
    color: Colors.neutral[600],
    marginTop: 4,
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: Theme.spacing.lg,
  },
  statCard: {
    flex: 1,
    alignItems: 'center',
    padding: Theme.spacing.md,
    marginHorizontal: Theme.spacing.xs,
  },
  statIconContainer: {
    width: 50,
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: Theme.spacing.sm,
  },
  statValue: {
    fontSize: Theme.fontSizes.xl,
    fontFamily: Theme.fonts.bold,
    color: Colors.neutral[900],
  },
  statLabel: {
    fontSize: Theme.fontSizes.sm,
    fontFamily: Theme.fonts.medium,
    color: Colors.neutral[600],
  },
  sectionContainer: {
    marginBottom: Theme.spacing.xl,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: Theme.spacing.md,
  },
  sectionTitle: {
    fontSize: Theme.fontSizes.lg,
    fontFamily: Theme.fonts.semiBold,
    color: Colors.neutral[800],
  },
  bookCard: {
    marginBottom: Theme.spacing.md,
  },
  bookCardContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  bookInfo: {
    flex: 1,
  },
  bookTitle: {
    fontSize: Theme.fontSizes.md,
    fontFamily: Theme.fonts.semiBold,
    color: Colors.neutral[800],
  },
  bookAuthor: {
    fontSize: Theme.fontSizes.sm,
    fontFamily: Theme.fonts.regular,
    color: Colors.neutral[600],
    marginBottom: 4,
  },
  borrowerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  borrowerText: {
    fontSize: Theme.fontSizes.xs,
    fontFamily: Theme.fonts.medium,
    color: Colors.neutral[500],
    marginLeft: 4,
  },
  dueDateContainer: {
    flexDirection: 'column',
    alignItems: 'flex-end',
  },
  dueDateLabel: {
    fontSize: Theme.fontSizes.xs,
    fontFamily: Theme.fonts.regular,
    color: Colors.neutral[500],
  },
  dueDateText: {
    fontSize: Theme.fontSizes.sm,
    fontFamily: Theme.fonts.medium,
    color: Colors.neutral[800],
  },
  overdue: {
    color: Colors.error[600],
  },
  emptyText: {
    fontSize: Theme.fontSizes.md,
    fontFamily: Theme.fonts.regular,
    color: Colors.neutral[500],
    textAlign: 'center',
    padding: Theme.spacing.md,
  },
});