import React from 'react';
import { View, Text, StyleSheet, ScrollView, Image, Switch, TouchableOpacity, Alert } from 'react-native';
import { useAuth } from '@/context/AuthContext';
import Colors from '@/constants/Colors';
import Theme from '@/constants/Theme';
import Button from '@/components/ui/Button';
import Card from '@/components/ui/Card';
import { LogOut, User, Bell, Moon, CircleHelp as HelpCircle, ShieldCheck, BookOpen } from 'lucide-react-native';

export default function SettingsScreen() {
  const { user, logout } = useAuth();
  const [darkMode, setDarkMode] = React.useState(false);
  const [notifications, setNotifications] = React.useState(true);

  const handleLogout = () => {
    Alert.alert(
      'Logout Confirmation',
      'Are you sure you want to logout?',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Logout', onPress: logout, style: 'destructive' },
      ]
    );
  };

  const handleToggleDarkMode = () => {
    setDarkMode(!darkMode);
    Alert.alert('Coming Soon', 'Dark mode will be available in the next update.');
  };

  const handleToggleNotifications = () => {
    setNotifications(!notifications);
  };

  const handleAbout = () => {
    Alert.alert(
      'Library Scanner',
      'Version 1.0.0\n\nA modern library management application designed to help librarians manage book inventory efficiently.',
      [{ text: 'OK' }]
    );
  };

  const handleHelp = () => {
    Alert.alert(
      'Help & Support',
      'For assistance, please contact support@libraryscanner.com or visit our help center at libraryscanner.com/help',
      [{ text: 'OK' }]
    );
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.contentContainer}>
      <View style={styles.profileSection}>
        <View style={styles.avatarContainer}>
          <Image
            source={{ uri: user?.profilePicture || 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg' }}
            style={styles.avatar}
          />
        </View>
        <View style={styles.profileInfo}>
          <Text style={styles.name}>{user?.name || 'Library User'}</Text>
          <Text style={styles.role}>{user?.role || 'Librarian'}</Text>
          <Text style={styles.email}>{user?.email || 'user@example.com'}</Text>
        </View>
      </View>

      <Text style={styles.sectionTitle}>Account</Text>
      <Card style={styles.optionCard}>
        <TouchableOpacity style={styles.optionItem}>
          <View style={styles.optionLeft}>
            <User size={20} color={Colors.primary[700]} />
            <Text style={styles.optionText}>Edit Profile</Text>
          </View>
          <Text style={styles.optionValue}>></Text>
        </TouchableOpacity>

        <View style={styles.divider} />

        <TouchableOpacity style={styles.optionItem}>
          <View style={styles.optionLeft}>
            <ShieldCheck size={20} color={Colors.primary[700]} />
            <Text style={styles.optionText}>Security</Text>
          </View>
          <Text style={styles.optionValue}>></Text>
        </TouchableOpacity>
      </Card>

      <Text style={styles.sectionTitle}>Preferences</Text>
      <Card style={styles.optionCard}>
        <View style={styles.optionItem}>
          <View style={styles.optionLeft}>
            <Moon size={20} color={Colors.primary[700]} />
            <Text style={styles.optionText}>Dark Mode</Text>
          </View>
          <Switch
            value={darkMode}
            onValueChange={handleToggleDarkMode}
            trackColor={{ false: Colors.neutral[300], true: Colors.primary[500] }}
            thumbColor={darkMode ? Colors.primary[700] : Colors.white}
          />
        </View>

        <View style={styles.divider} />

        <View style={styles.optionItem}>
          <View style={styles.optionLeft}>
            <Bell size={20} color={Colors.primary[700]} />
            <Text style={styles.optionText}>Notifications</Text>
          </View>
          <Switch
            value={notifications}
            onValueChange={handleToggleNotifications}
            trackColor={{ false: Colors.neutral[300], true: Colors.primary[500] }}
            thumbColor={notifications ? Colors.primary[700] : Colors.white}
          />
        </View>
      </Card>

      <Text style={styles.sectionTitle}>Information</Text>
      <Card style={styles.optionCard}>
        <TouchableOpacity style={styles.optionItem} onPress={handleAbout}>
          <View style={styles.optionLeft}>
            <BookOpen size={20} color={Colors.primary[700]} />
            <Text style={styles.optionText}>About</Text>
          </View>
          <Text style={styles.optionValue}>></Text>
        </TouchableOpacity>

        <View style={styles.divider} />

        <TouchableOpacity style={styles.optionItem} onPress={handleHelp}>
          <View style={styles.optionLeft}>
            <HelpCircle size={20} color={Colors.primary[700]} />
            <Text style={styles.optionText}>Help & Support</Text>
          </View>
          <Text style={styles.optionValue}>></Text>
        </TouchableOpacity>
      </Card>

      <Button
        title="Logout"
        onPress={handleLogout}
        variant="outline"
        icon={<LogOut size={20} color={Colors.primary[700]} />}
        style={styles.logoutButton}
      />

      <Text style={styles.versionText}>Version 1.0.0</Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.neutral[50],
  },
  contentContainer: {
    padding: Theme.spacing.md,
  },
  profileSection: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.white,
    borderRadius: Theme.borderRadius.lg,
    padding: Theme.spacing.lg,
    marginBottom: Theme.spacing.lg,
    ...Theme.shadows.md,
  },
  avatarContainer: {
    width: 70,
    height: 70,
    borderRadius: 35,
    overflow: 'hidden',
    ...Theme.shadows.sm,
  },
  avatar: {
    width: '100%',
    height: '100%',
  },
  profileInfo: {
    marginLeft: Theme.spacing.md,
  },
  name: {
    fontSize: Theme.fontSizes.lg,
    fontFamily: Theme.fonts.bold,
    color: Colors.neutral[900],
    marginBottom: 2,
  },
  role: {
    fontSize: Theme.fontSizes.sm,
    fontFamily: Theme.fonts.medium,
    color: Colors.primary[600],
    marginBottom: 4,
  },
  email: {
    fontSize: Theme.fontSizes.sm,
    fontFamily: Theme.fonts.regular,
    color: Colors.neutral[600],
  },
  sectionTitle: {
    fontSize: Theme.fontSizes.md,
    fontFamily: Theme.fonts.semiBold,
    color: Colors.neutral[700],
    marginBottom: Theme.spacing.sm,
    marginTop: Theme.spacing.md,
    paddingHorizontal: Theme.spacing.xs,
  },
  optionCard: {
    padding: 0,
    overflow: 'hidden',
  },
  optionItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: Theme.spacing.md,
  },
  optionLeft: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  optionText: {
    fontSize: Theme.fontSizes.md,
    fontFamily: Theme.fonts.regular,
    color: Colors.neutral[800],
    marginLeft: Theme.spacing.md,
  },
  optionValue: {
    fontSize: Theme.fontSizes.md,
    fontFamily: Theme.fonts.regular,
    color: Colors.neutral[400],
  },
  divider: {
    height: 1,
    backgroundColor: Colors.neutral[200],
    marginHorizontal: Theme.spacing.md,
  },
  logoutButton: {
    marginTop: Theme.spacing.xl,
  },
  versionText: {
    fontSize: Theme.fontSizes.sm,
    fontFamily: Theme.fonts.regular,
    color: Colors.neutral[500],
    textAlign: 'center',
    marginTop: Theme.spacing.md,
    marginBottom: Theme.spacing.xl,
  },
});